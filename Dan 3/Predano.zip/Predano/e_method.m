b = fscanf(fopen('FinalVector2.txt','r'),'%e');
A = toeplitz(fscanf(fopen('Kernel1.txt','r'), '%e'));
n = 51;
k = 20;

x_cos = cos_method(n, k, A, b);


b = fscanf(fopen('FinalVector2.txt','r'),'%e');
x_cos_A = A*x_cos;
figure(1)
plot(b, "b")
hold on
plot(x_cos_A)
hold off

