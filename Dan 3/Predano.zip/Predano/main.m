b_1 = fscanf(fopen('FinalVector1.txt','r'),'%e');
b_2 = fscanf(fopen('FinalVector2.txt','r'),'%e');
b_3 = fscanf(fopen('FinalVector3.txt','r'),'%e');
b_4 = fscanf(fopen('FinalVector4.txt','r'),'%e');
b_5 = fscanf(fopen('FinalVector5.txt','r'),'%e');
A = toeplitz(fscanf(fopen('Kernel1.txt','r'), '%e'));

b_1 = fscanf(fopen('FinalVector1.txt','r'),'%e');
k = 10;
n = length(b_1);
%Primjena metode projekcije na potprostor razapet kosinusima
x_1 = cos_method(n, k, A, b_1);
x_2 = cos_method(n, k, A, b_2);
x_3 = cos_method(n, k, A, b_3);
x_4 = cos_method(n, k, A, b_4);
x_5 = cos_method(n, k, A, b_5);

x_1_A = A*x_1;
figure(1)
plot(b_1, "b")
hold on;
plot(x_1_A, "r")
hold off

x_2_A = A*x_2;
figure(2)
plot(b_2, "b")
hold on;
plot(x_2_A, "r")
hold off

x_3_A = A*x_3;
figure(3)
plot(b_3, "b")
hold on;
plot(x_3_A, "r")
hold off

x_4_A = A*x_4;
figure(4)
plot(b_4, "b")
hold on;
plot(x_4_A, "r")
hold off

x_5_A = A*x_5;
figure(5)
plot(b_5, "b")
hold on;
plot(x_5_A, "r")
hold off

%Trebalo bi prilagodit bazu potprostora po svakom signalu. Prilagodavanje
%baze opisano je u txt fileu Komentari za 1. signal. 


