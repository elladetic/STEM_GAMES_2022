
function x = cos_method(n, k, A, b)

    V = zeros(n,n); 

    for i = 0:(n-1)
        for j = 0:(n-1)
            V(i+1,j+1) = cos( pi * j * (2*i + 1)/(2*(n)));
        end
    end

    for i = 1:n
        V(:, i) = V(:, i) / norm(V(:, i));
    end

    tmp = pinv(A*V(:, 1:k));
    x = V(:, 1:k) * (tmp * b );  
    [M,I] = max(abs(b-x));
    V(:, I) = eye(n,1);


end